package com.mygdx.game.views;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.scenes.scene2d.Actor;

public class ChessSquare extends Actor {

	private Texture texture;
	public ChessSquare() {
		// TODO Auto-generated constructor stub
	}

}
