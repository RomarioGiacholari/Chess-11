package com.mygdx.game.views;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Batch;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.mygdx.game.models.Board;

public class IsSelectedSprite extends Actor{

	Texture texture = new Texture(Gdx.files.internal("transparentBlue60x60.png"));
	//Texture texture = new Texture(Gdx.files.internal("badlogic.jpg"));
	Board board = new Board();
	private int pieceX;
	private int pieceY;
	
	public IsSelectedSprite() {
		board.setUp();
	}
	
	public void draw(Batch batch) {
		batch.draw(texture,getPieceX(),getPieceY());
	}
	
	public int getPieceX() {
		return pieceX;
	}
	
	public int getPieceY() {
		return pieceY;
	}
	
	public void setPos(int x, int y) {
		int row = 0;

		pieceX = x*60;
		pieceY = row*60;
	}
	
	public void setX(int x) {
		pieceX = x;
	}
	
	public void setY(int y) {
		pieceY = y;
	}
	

}
